----
# [SELFBOT-BY:MAX](https://line.me/R/ti/p/~maxbotline)
PESAN ANE JANGAN DI PERJUAL BELIKAN 
Thank's to:
Allah SWT 

```

